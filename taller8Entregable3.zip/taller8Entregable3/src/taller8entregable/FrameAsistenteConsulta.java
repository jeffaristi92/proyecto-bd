package taller8entregable;

import java.awt.Dimension;
import javax.swing.*;

public class FrameAsistenteConsulta extends JFrame {

    public FrameAsistenteConsulta() {

        setTitle("Asistente de Consulta");

        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {

            JOptionPane.showMessageDialog(this, "Imposible modificar el tema visual", "", JOptionPane.ERROR_MESSAGE);
        }
        setSize(650, 415);
        setLocationRelativeTo(null);
        setVisible(true);
        setMinimumSize(new Dimension(650, 415));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane panelGeneral = new JTabbedPane();
        
        add(panelGeneral);

    }
}
