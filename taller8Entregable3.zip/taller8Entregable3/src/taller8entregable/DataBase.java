package taller8entregable;

import java.sql.*;
import javax.swing.JOptionPane;

public class DataBase {

    static Connection db;
    static String servidor, baseDeDatos;
    static boolean ejecucionExitosa = true;

    public static void setServidor(String valor) {

        servidor = valor;
    }

    public static void setBaseDeDatos(String valor) {

        baseDeDatos = valor;
    }

    public String Consulta(String consulta) {

        ResultSet rs;
        String valido = "";
        Statement stmt;
        ResultSetMetaData jhon;
        boolean error_loading_driver = false;
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "No se encontro el controlador", JOptionPane.ERROR_MESSAGE);
            error_loading_driver = true;
        }
        if (!error_loading_driver) {
            boolean connected = false;
            try {
                System.out.println("Conectando a la base de datos! --> metodo consulta");

                //db = DriverManager.getConnection("jdbc:mysql://SQL09.FREEMYSQL.NET/tallereseisc", "tallerpi", "taller");
                //System.out.println("imprimiendo desde base de datos. Servidor: " + servidor + " Base De Datos: " + baseDeDatos);
                db = DriverManager.getConnection("jdbc:mysql://" + servidor + "/" + baseDeDatos + "", "tallerpi", "taller");
                connected = true;
            } catch (SQLException se) {
                JOptionPane.showMessageDialog(null, se.getMessage(), "Error en base de datos", JOptionPane.ERROR_MESSAGE);
                System.out.println("No se ha podido conectar a la base. --> metodo consulta");
            }
            if (connected) {
                System.out.println("Ya se ha conectado a la base de datos --> metodo consulta");
                try {
                    stmt = db.createStatement();
                    System.out.println(consulta + " imprimiendo desde DataBase --> metodo consulta");
                    rs = stmt.executeQuery(consulta);
                    //stmt.executeUpdate(consulta);
                    while (rs.next()) {
                        valido = rs.getString(1);
                        System.out.println(valido + " imprimiendo desde DataBase --> metodo consulta");
                        jhon = rs.getMetaData();

                        System.out.println("imprimiendo nombre de la segunda columna --> metodo consulta " + jhon.getColumnCount());
                    }
                    rs.close();
                    db.close();
                    ejecucionExitosa = true;
                    System.out.println("Base de datos cerrada --> metodo consulta");
                } catch (SQLException se) {
                    JOptionPane.showMessageDialog(null, se.getMessage(), "Error en base de datos", JOptionPane.ERROR_MESSAGE);
                    System.out.println("No se ha podido cerrar la base. --> metodo consulta");
                    ejecucionExitosa = false;
                }
            }
        } else {
            System.out.println("No se ha podido encontrar el driver JDBC para MySql. --> metodo consulta");
        }

        return valido;
    }

    public void Actualizar(String cadena) {

        Statement stmt;
        boolean error_loading_driver = false;

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException cnfe) {
            JOptionPane.showMessageDialog(null, cnfe.getMessage(), "No se encontro el controlador", JOptionPane.ERROR_MESSAGE);
            error_loading_driver = true;
        }
        if (!error_loading_driver) {
            boolean connected = false;
            try {
                System.out.println("Conectando a la base de datos!");

                //servidor = SQL09.FREEMYSQL.NET
                //base de datos = tallereseisc
                db = DriverManager.getConnection("jdbc:mysql://" + servidor + "/" + baseDeDatos + "", "tallerpi", "taller");
                connected = true;
            } catch (SQLException se) {
                JOptionPane.showMessageDialog(null, se.getMessage(), "Error en base de datos", JOptionPane.ERROR_MESSAGE);
                System.out.println("No se ha podido conectar a la base.");
            }
            if (connected) {
                System.out.println("Ya se ha conectado a la base de datos");

                try {
                    stmt = db.createStatement();
                    System.out.println(cadena);
                    stmt.executeUpdate(cadena);
                    db.close();
                    ejecucionExitosa = true;
                    System.out.println("Base de datos cerrada");
                } catch (SQLException se) {

                    JOptionPane.showMessageDialog(null, se.getMessage(), "Error en base de datos", JOptionPane.ERROR_MESSAGE);
                    System.out.println("No se ha podido cerrar la base.");
                    ejecucionExitosa = false;
                }
            }
        } else {
            System.out.println("No se ha podido encontrar el driver JDBC para MySql.");
        }

    }
}//fin clase DataBase

