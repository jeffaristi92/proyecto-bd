package taller8entregable;

import javax.swing.JFrame;

public class Taller8Entregable {

    public static void main(String[] args) {

        InicioSesion frame = new InicioSesion();     
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
}
