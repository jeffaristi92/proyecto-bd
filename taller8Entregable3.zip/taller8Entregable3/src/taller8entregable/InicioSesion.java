package taller8entregable;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class InicioSesion extends JFrame {

    private JLabel usuario, contrasenia, jLabelBaseDeDatos, jLabelServidor;
    private JTextField campoUsuario, baseDeDatos, servidor;
    private JPasswordField campoContrasenia;
    private JButton aceptar, cancelar;
    private Panel panel;

    public InicioSesion() {

        super("Inicio De Sesion");

        panel = new Panel();

        this.setResizable(false);
        this.setSize(430, 250);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        add(panel);

    }

    private class Panel extends JPanel {

        public Panel() {

            ManejadorDeEvento manejador = new ManejadorDeEvento();

            this.setLayout(new GridLayout(5, 2, 10, 10));
            this.setBackground(Color.BLACK);

            usuario = new JLabel();
            usuario.setText("Nombre de Usuario");
            usuario.setForeground(Color.WHITE);

            contrasenia = new JLabel();
            contrasenia.setText("Contraseña");
            contrasenia.setForeground(Color.WHITE);

            campoUsuario = new JTextField("admin");
            campoUsuario.addActionListener(manejador);

            campoContrasenia = new JPasswordField("admin");
            campoContrasenia.addActionListener(manejador);

            jLabelBaseDeDatos = new JLabel();
            jLabelBaseDeDatos.setText("Base De Datos");
            jLabelBaseDeDatos.setForeground(Color.WHITE);

            baseDeDatos = new JTextField("tallereseisc");
            baseDeDatos.addActionListener(manejador);

            jLabelServidor = new JLabel();
            jLabelServidor.setText("Servidor");
            jLabelServidor.setForeground(Color.WHITE);

            servidor = new JTextField("SQL09.FREEMYSQL.NET");
            servidor.addActionListener(manejador);

            aceptar = new JButton("Entrar");
            aceptar.addActionListener(manejador);

            cancelar = new JButton("Cancelar");
            cancelar.addActionListener(manejador);

            Border border = new LineBorder(Color.WHITE);
            Font font = new Font("Arial", Font.PLAIN, 15);

            this.setBorder(new TitledBorder(border, "Inicio", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.CENTER, font, Color.WHITE));

            add(usuario);
            add(campoUsuario);
            add(contrasenia);
            add(campoContrasenia);
            add(jLabelBaseDeDatos);
            add(baseDeDatos);
            add(jLabelServidor);
            add(servidor);
            add(aceptar);
            add(cancelar);

        }
    }

    private class ManejadorDeEvento implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent evento) {

            DataBase objDataBase = new DataBase();
            String consulta;

            if (evento.getSource() == aceptar || evento.getSource() == campoUsuario || evento.getSource() == campoContrasenia || evento.getSource() == servidor || evento.getSource() == baseDeDatos) {


                String contrasenia = new String(campoContrasenia.getPassword());

                if (campoUsuario.getText().length() < 1 || contrasenia.length() < 1 || servidor.getText().length() < 1 || baseDeDatos.getText().length() < 1) {

                    JOptionPane.showMessageDialog(InicioSesion.this, "No se pude dejar un campo vacio, porfavor llene todos los datos");
                } else {


                    DataBase.setServidor(servidor.getText());
                    DataBase.setBaseDeDatos(baseDeDatos.getText());

                    consulta = "SELECT username FROM login WHERE username = '" + campoUsuario.getText() + "'";
                    String usuario = objDataBase.Consulta(consulta);
                   // System.out.println(usuario + " imprimiendo desde inicio sesion");

                    consulta = "SELECT password FROM login WHERE password = '" + contrasenia + "'";
                    String password = objDataBase.Consulta(consulta);
                    //System.out.println(password + " imprimiendo desde inicio sesion");

                    if (!(usuario.equals("") || password.equals(""))) {

                        dispose();
                        FrameAsistenteConsulta frame = new FrameAsistenteConsulta();

                    } else {
                        JOptionPane.showMessageDialog(InicioSesion.this, "Datos Incorrectos, Por favor verifiquelos");

                    }

                }//fin else --> si se cumple que no se deje ningun espacio vacio

            }//if evento.getSource() == aceptar

            if (evento.getSource() == cancelar) {

                System.exit(0);
            }
        }
    }
}
